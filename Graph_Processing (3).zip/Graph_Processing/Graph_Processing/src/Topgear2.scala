import scala.collection.mutable.ArrayBuffer
import scala.collection.mutable.Queue
import java.io._
import scala.io._
object Topgear2 {
   
  def main(args: Array[String]) 
    {
        val  rows = new ArrayBuffer[String]()
  
        //code to read each line of text file//
        Source.fromFile("/Users/test/workspace/Graph_Processing/transfers.txt" ).foreach { 
        
        print
     }
        
        println()
    val bufferedSource = io.Source.fromFile("/Users/test/workspace/Graph_Processing/transfers.txt")
    for (line <- bufferedSource.getLines) {
     
        rows +=line.trim
       
    }
        //read first line of  txt doc to decide number of vertex//
      val len =rows(0).toInt+1
      
      //multidimentional matrix for each vertex showing connection //
      var myMatrix = Array.ofDim[Int](len, len)
      for(m<- 0 to len-1)
          {
            for(n<- 0 to len-1)
            {
              myMatrix(m)(n)=0
            }
           
          }
      //add each edge by this function in multidimentional array//
         def addedge(i:Int,j:Int)
        {
           myMatrix(i)(j)=1
          
        }
       
        rows.foreach(i=>
           
          if((i.length()>3) && i!=" ")
          { 
           //println(i)
           val a =Integer.parseInt(i.substring(0,2).trim())
           val b =Integer.parseInt(i.substring(2,4).trim())
          
           addedge(a,b)
          }
         )
         
         var queue = Queue[Int]()
         //declare an array to show the visited vertex
        var visited:Array[Int]=new Array(len)
        for(i<-0 to len-1)
        {
          visited(i)=0
        }
        
        
        //put the first vertex from which traversing starts
        queue.enqueue(1)
        
        //iterate until the queue is empty
        while (!queue.isEmpty)
        {
           var i= queue.dequeue
           print(i+" ")
           //if(visited(i)!=1)
           Insertfrst(i)
        
        }
      
        //enqueue the adjacent vertex
        def Insertfrst(i:Int)
         {    visited(i)=1
             for(j<- 0 to len-1)
            {
            if(myMatrix(i)(j)==1 && visited(j)==0)
             { // print(myMatrix(i)(j))
              if(visited(j)!=1)
               {queue.enqueue(j)
               visited(j)=1}
                
              
            }
        
         
         }
         }
    
      
        
    }
}

